import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.JButton;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class viewacc extends JFrame {

	private JPanel contentPane;
	private JTable table;
	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\display.txt";
	public static void main(String[] args) throws IOException {
		File file1=new File(filename1);
		file1.createNewFile();
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					viewacc frame = new viewacc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public viewacc() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 954, 47);
		contentPane.add(panel);
		
		JLabel lblNewLabel = new JLabel("VIEW DETAILS");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
		panel.add(lblNewLabel);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				nextpage np=new nextpage();
				np.setVisible(true);
			}
		});
		btnBack.setBackground(Color.RED);
		btnBack.setForeground(Color.WHITE);
		btnBack.setFont(new Font("Times New Roman", Font.BOLD, 28));
		btnBack.setBounds(392, 445, 183, 48);
		contentPane.add(btnBack);
		String bankn=nextpage.bankname;
		try{
			String[] values;
			Object[][] row=new Object[20][6];
			int i=0;
			System.out.println("here3");
			File file1=new File(filename1);
			Scanner sc=new Scanner(file1);
			
			while(sc.hasNextLine())
			{
				String mystr=sc.nextLine();
				System.out.println(mystr);
				System.out.println(mystr.startsWith("*")||mystr.startsWith("\n"));
				if(mystr.startsWith("*")||mystr.startsWith("\n")||mystr.length()<10)continue;
				System.out.println("here4");
				values=mystr.split(",");
				int pos=values[5].indexOf("$");
				System.out.println(pos);
				String ds=values[5].substring(0,pos);
				values[5]=ds;
				System.out.println(ds);
				
				if(values[0].equals(bankn))
				{
					for(int j=0;j<6;j++)
					{
						System.out.println("here5");
						System.out.println(values[j]);
						row[i][j]=values[j];
						System.out.println(row[i][j]);
	
					}
					values=null;
					i++;
				}

				
			}
			Object[] colname={"Bank Name","Ifsc code","Account no","Holder Name","Account Type","Balance"};
			
			table = new JTable(row,colname);
			JScrollPane scrollp = new JScrollPane(table);
			
			System.out.println("ok");
			table.setBounds(85,100,100,100);
			table.setBackground(Color.WHITE);
			table.setForeground(Color.BLACK);
			table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			contentPane.add(table);
			//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			scrollp.setViewportView(table);
			scrollp.setBounds(85,120,800,250);
			scrollp.setBackground(Color.WHITE);
			scrollp.setForeground(Color.BLACK);
			scrollp.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			scrollp.getHorizontalScrollBar();
			scrollp.getVerticalScrollBar();
			contentPane.add(scrollp);
			
			
			
			
		}
		catch(Exception e1)
		{
			System.out.println(e1);
		}
	}
}
