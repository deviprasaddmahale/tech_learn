import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JPasswordField;


public class adminpage extends JFrame {

	private JPanel contentPane;
	private JTextField t1;
	private JPasswordField t2;

	/**
	 * Launch the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\user.txt";
	public static  String filename3="C:\\user\\display.txt";
	public static String filename4="C:\\user\\transaction_logs.txt";
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, IOException {
		File file1=new File(filename1);
		file1.createNewFile();
		File file2 =new File(filename2);
		file2.createNewFile();
		File file3 =new File(filename3);
		file3.createNewFile();
		RandomAccessFile raf3= new RandomAccessFile(filename3, "rw");
		raf3.seek(0);
		if(raf3.readLine()==null)raf3.writeBytes("****");
		File file4 =new File(filename4);
		file4.createNewFile();
		UIManager.setLookAndFeel( "com.jtattoo.plaf.aluminium.AluminiumLookAndFeel" );
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminpage frame = new adminpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminpage() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 928, 51);
		panel.setBackground(Color.RED);
		contentPane.add(panel);
		
		JLabel lblAdminPage = new JLabel("ADMIN PAGE ");
		lblAdminPage.setFont(new Font("Times New Roman", Font.BOLD, 28));
		lblAdminPage.setForeground(Color.WHITE);
		panel.add(lblAdminPage);
		
		JLabel lblNewLabel = new JLabel("USER NAME:");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 26));
		lblNewLabel.setBounds(241, 157, 171, 36);
		contentPane.add(lblNewLabel);
		
		t1 = new JTextField();
		t1.setHorizontalAlignment(SwingConstants.CENTER);
		t1.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		t1.setBounds(438, 157, 382, 40);
		contentPane.add(t1);
		t1.setColumns(10);
		
		JLabel lblPassWord = new JLabel("PASSWORD:");
		lblPassWord.setForeground(Color.RED);
		lblPassWord.setFont(new Font("Times New Roman", Font.PLAIN, 26));
		lblPassWord.setBounds(241, 231, 171, 50);
		contentPane.add(lblPassWord);
		t2 = new JPasswordField();
		t2.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		t2.setHorizontalAlignment(SwingConstants.CENTER);
		t2.setEchoChar('*');
		t2.setBounds(442, 231, 378, 40);
		contentPane.add(t2);
		
		JButton btnLogin = new JButton("LOGIN");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String uname=t1.getText();
				String pword=t2.getText();
				if(uname.equalsIgnoreCase("admin")&&pword.equals("password"))
				{
					nextpage np=new nextpage();
					np.setVisible(true);
					
				}
				else
				{
					JOptionPane.showMessageDialog(null,"Enter proper Username and password");
				}
			}
		});
		btnLogin.setBackground(Color.RED);
		btnLogin.setForeground(Color.WHITE);
		btnLogin.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnLogin.setBounds(396, 367, 161, 36);
		contentPane.add(btnLogin);
		
		
	}
}
