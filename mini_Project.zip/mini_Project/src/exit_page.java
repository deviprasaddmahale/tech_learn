import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class exit_page extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					exit_page frame = new exit_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public exit_page() {
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300, 100, 800, 450);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.RED);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblThankuForUsing = new JLabel("THANKU FOR USING DM ASSOCIATION BANK ");
		lblThankuForUsing.setForeground(Color.WHITE);
		lblThankuForUsing.setBackground(Color.RED);
		lblThankuForUsing.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblThankuForUsing.setBounds(72, 133, 698, 36);
		contentPane.add(lblThankuForUsing);

		JLabel lblVisitAgain = new JLabel("VISIT AGAIN!!!");
		lblVisitAgain.setHorizontalAlignment(SwingConstants.CENTER);
		lblVisitAgain.setFont(new Font("Times New Roman", Font.PLAIN, 30));
		lblVisitAgain.setForeground(Color.WHITE);
		lblVisitAgain.setBackground(Color.RED);
		lblVisitAgain.setBounds(269, 245, 235, 36);
		contentPane.add(lblVisitAgain);
	}
}
