import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.SwingConstants;

import net.proteanit.sql.DbUtils;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class updateacc extends JFrame {

	private JPanel contentPane;
	private JTextField accn;
	private JTextField name;
	private JTextField email;
	private JTextField phone;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\display.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updateacc frame = new updateacc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public updateacc() {
		setResizable(false);
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 916, 42);
		contentPane.add(panel);

		JLabel lblUpdateAccount = new JLabel("UPDATE ACCOUNT");
		lblUpdateAccount.setForeground(Color.WHITE);
		lblUpdateAccount.setFont(new Font("Times New Roman", Font.BOLD, 28));
		panel.add(lblUpdateAccount);

		accn = new JTextField();
		accn.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		accn.setHorizontalAlignment(SwingConstants.CENTER);
		accn.setBounds(48, 368, 303, 46);
		contentPane.add(accn);
		accn.setColumns(10);

		JLabel lblEnterAccountNumber = new JLabel("Enter account number to update");
		lblEnterAccountNumber.setForeground(Color.RED);
		lblEnterAccountNumber.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEnterAccountNumber.setBounds(48, 334, 295, 37);
		contentPane.add(lblEnterAccountNumber);

		name = new JTextField();
		name.setHorizontalAlignment(SwingConstants.CENTER);
		name.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		name.setBounds(401, 368, 295, 46);
		contentPane.add(name);
		name.setColumns(10);
		String bankn=nextpage.bankname;

		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try{
					String name1=name.getText();
					Pattern po=Pattern.compile("[a-zA-Z]+([ '.][a-zA-Z]+)*" );
					Matcher mo=po.matcher(name1);
					boolean to1=mo.find()&&mo.group().equals(name1);
					if(to1==false)
					{
						JOptionPane p141=new JOptionPane("Enter proper name");
						JDialog d141=p141.createDialog(null,"");
						d141.setAlwaysOnTop(true);
						d141.show();
						int res141 = 0;
						if(res141==JOptionPane.OK_OPTION)
						{
							name.setText(null);

						}

					}
					String email1=email.getText();
					Pattern p1=Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\."+ 
							"[a-zA-Z0-9_+&*-]+)*@" + 
							"(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
							"A-Z]{2,7}$" );
					Matcher m=p1.matcher(email1);
					boolean t=m.find()&&m.group().equals(email1);
					if(t==false)
					{
						JOptionPane p41=new JOptionPane("Enter proper email id");
						JDialog d41=p41.createDialog(null,"");
						d41.setAlwaysOnTop(true);
						d41.show();
						int res41 = 0;
						if(res41==JOptionPane.OK_OPTION)
						{
							email.setText(null);

						}

					}
					String phone1=phone.getText();
					Pattern p2=Pattern.compile("(0/91)?[7-9][0-9]{9}");
					Matcher m1=p2.matcher(phone1);
					boolean t1=m1.find()&&m1.group().equals(phone1);
					if(t1==false)
					{
						JOptionPane p4=new JOptionPane("Enter proper phone number");
						JDialog d4=p4.createDialog(null,"");
						d4.setAlwaysOnTop(true);
						d4.show();
						int res4 = 0;
						if(res4==JOptionPane.OK_OPTION)
						{
							phone.setText(null);

						}

					}
					String accno=accn.getText();
					if(t1==true&&t==true&&to1==true){
						String[] values1;
						int i=0,pos=0,flag=0;
						System.out.println("here3");
						RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
						File file1=new File(filename2);
						Scanner sc=new Scanner(file1);


						while(sc.hasNextLine())
						{
							String mystr=sc.nextLine();
							System.out.println(mystr);
							if(mystr.startsWith("*")||mystr.startsWith("\n")||mystr.length()<10)continue;
							System.out.println("here4");
							values1=mystr.split(",");

							String ds=values1[5].replace('$',' ').trim();
							values1[5]=ds;
							System.out.println(ds);

							if(values1[2].equals(accno))
							{

								while(true)
								{

									raf2.seek(pos);
									pos=(int) raf2.getFilePointer();
									String mystr1=raf2.readLine();
									System.out.println("mystr1:"+mystr1);
									if(mystr1.startsWith("*")||mystr1.startsWith("\n")||mystr1.length()<10)
									{
										pos=(int) raf2.getFilePointer();
										continue;
									}
									values1=mystr1.split(",");
									System.out.println(values1[2]);
									System.out.println(values1[2].equals(accno));

									if(values1[2].equals(accno))
									{

										String b=values1[0]+","+values1[1]+","+values1[2]+","+name1+","+values1[4]+","+values1[5]+"\n";
										System.out.println("am here:"+b);
										raf2.seek(pos);
										raf2.writeBytes(b);
										flag=1;
										long addr=Math.abs(accno.hashCode()%19937);
										RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
										raf.seek(addr);
										String[] values2=raf.readLine().split(",");
										String str=values2[0]+","+values2[1]+","+name1+","+values2[3]+","+values2[4]+","+phone1+","+email1+","+values2[7];
										raf.seek(addr);
										raf.writeBytes(str);
										break;
									}
									values1=null;
									pos=(int) raf2.getFilePointer();
								}
							}
							if(flag==1)break;



						}


						if(flag==1)
						{
							Date df =new Date();
							String[] to={email1};  
							String subject="Your account details has beeen updated in our bank "+bankn+".";
							String body="Mr/Mrs "+ name1 +", your account details has been updated in our bank "+bankn+" with bearing account number:"+accno
									+" with phone number"+phone1+" on "+df;
							System.out.println(body);

							Main.sendFromGMail(to,subject,body);
							JOptionPane p=new JOptionPane("Account details has been updated");
							JDialog d=p.createDialog(null,"");
							d.setAlwaysOnTop(true);
							d.show();
							int res = 0;
							if(res==JOptionPane.OK_OPTION)
							{
								nextpage np=new nextpage();
								np.setVisible(true);
							}
						}
						else
						{
							JOptionPane p11=new JOptionPane("Account details has not been updated");
							JDialog d1=p11.createDialog(null,"");
							d1.setAlwaysOnTop(true);
							d1.show();
							int res1 = 0;
							if(res1==JOptionPane.OK_OPTION)
							{
								nextpage np=new nextpage();
								np.setVisible(true);
							}
						}
					}
					else
					{
						JOptionPane p11=new JOptionPane("Enter proper account number");
						JDialog d1=p11.createDialog(null,"");
						d1.setAlwaysOnTop(true);
						d1.show();
						int res1 = 0;
						if(res1==JOptionPane.OK_OPTION)
						{
							accn.setText(null);
						}
					}


				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
		});
		btnUpdate.setBackground(Color.RED);
		btnUpdate.setForeground(Color.WHITE);
		btnUpdate.setFont(new Font("Times New Roman", Font.BOLD, 28));
		btnUpdate.setBounds(708, 409, 206, 42);
		contentPane.add(btnUpdate);

		JLabel lblHolderName = new JLabel("Holder name");
		lblHolderName.setForeground(Color.RED);
		lblHolderName.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblHolderName.setBounds(401, 340, 130, 25);
		contentPane.add(lblHolderName);

		email = new JTextField();
		email.setHorizontalAlignment(SwingConstants.CENTER);
		email.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		email.setBounds(48, 454, 303, 42);
		contentPane.add(email);
		email.setColumns(10);

		JLabel lblEmail = new JLabel("Email");
		lblEmail.setForeground(Color.RED);
		lblEmail.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblEmail.setBounds(48, 425, 116, 16);
		contentPane.add(lblEmail);

		phone = new JTextField();
		phone.setHorizontalAlignment(SwingConstants.CENTER);
		phone.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		phone.setBounds(401, 450, 295, 46);
		contentPane.add(phone);
		phone.setColumns(10);

		JLabel lblPhoneNo = new JLabel("Phone no");
		lblPhoneNo.setForeground(Color.RED);
		lblPhoneNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblPhoneNo.setBounds(403, 418, 86, 25);
		contentPane.add(lblPhoneNo);

		JLabel lblAccountNo = new JLabel("Account Details");
		lblAccountNo.setForeground(Color.RED);
		lblAccountNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAccountNo.setBounds(48,55, 206, 25);
		contentPane.add(lblAccountNo);
		try{
			String[] values;
			Object[][] row=new Object[20][6];
			int i=0;
			System.out.println("here3");
			File file1=new File(filename2);
			Scanner sc=new Scanner(file1);

			while(sc.hasNextLine())
			{
				String mystr=sc.nextLine();
				if(mystr.startsWith("*")||mystr.startsWith("\n")||mystr.length()<10)continue;
				System.out.println("here4");
				values=mystr.split(",");
				int pos=values[5].indexOf("$");
				String ds=values[5].substring(0,pos).trim();
				values[5]=ds;
				System.out.println(ds);

				if(values[0].equals(bankn))
				{
					for(int j=0;j<values.length;j++)
					{
						System.out.println("here5");
						System.out.println(values[j]);
						row[i][j]=values[j];
						System.out.println(row[i][j]);

					}
					values=null;
					i++;
				}


			}
			Object[] colname={"Bank Name","Ifsc code","Account no","Holder Name","Account Type","Balance"};



			table = new JTable(row,colname);
			JScrollPane scrollp = new JScrollPane(table);
			System.out.println("ok");
			table.setBounds(85,100,100,100);
			table.setBackground(Color.WHITE);
			table.setForeground(Color.BLACK);
			table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			contentPane.add(table);
			//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			scrollp.setViewportView(table);
			scrollp.setBounds(48,80,850,200);
			scrollp.setBackground(Color.WHITE);
			scrollp.setForeground(Color.BLACK);
			scrollp.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			scrollp.getHorizontalScrollBar();
			scrollp.getVerticalScrollBar();
			contentPane.add(scrollp);




		}
		catch(Exception e1)
		{
			System.out.println(e1);
		}

	}
}
