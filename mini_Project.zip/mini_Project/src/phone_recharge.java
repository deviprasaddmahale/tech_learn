import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;
import java.awt.Panel;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.SwingConstants;
import javax.swing.JTextField;

import java.awt.Button;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class phone_recharge extends JFrame {

	private JPanel contentPane;
	private JTextField tphone;
	private JTextField tamount;
	Page_1 pg =new Page_1();
	public String acc=pg.acc;

	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\display.txt";
	public static  String filename3="C:\\user\\transaction_logs.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					phone_recharge frame = new phone_recharge();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public phone_recharge() {
		setAutoRequestFocus(false);
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(400, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 432, 39);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		panel.add(label);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 20));
		label.setBackground(Color.RED);

		JLabel lblPhoneNo = new JLabel("PHONE NO:");
		lblPhoneNo.setForeground(Color.RED);
		lblPhoneNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblPhoneNo.setBounds(36, 86, 111, 16);
		contentPane.add(lblPhoneNo);

		tphone = new JTextField();
		tphone.setHorizontalAlignment(SwingConstants.CENTER);
		tphone.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		tphone.setBounds(147, 85, 233, 22);
		contentPane.add(tphone);
		tphone.setColumns(10);

		JLabel lblAccountNo = new JLabel("AMOUNT:");
		lblAccountNo.setForeground(Color.RED);
		lblAccountNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAccountNo.setBounds(36, 131, 105, 16);
		contentPane.add(lblAccountNo);

		tamount = new JTextField();
		tamount.setHorizontalAlignment(SwingConstants.CENTER);
		tamount.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		tamount.setBounds(147, 130, 233, 22);
		contentPane.add(tamount);
		tamount.setColumns(10);

		JButton btnNewButton = new JButton("RECHARGE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String amo=tamount.getText();
				String phone=tphone.getText();
				double bal ;
				String email;

				try{
					int flag=0;
					long addr=Math.abs(acc.hashCode()%19937);
					RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
					raf.seek(addr);
					String[] values=raf.readLine().split(",");
					int pos=values[7].indexOf("$");
					String ds=values[7].substring(0,pos);
					values[7]=ds;
					Pattern p1=Pattern.compile("(0/91)?[7-9][0-9]{9}");
					Matcher m=p1.matcher(phone);
					boolean t=m.find()&&m.group().equals(phone);
					System.out.println("t="+t);
					Pattern p23=Pattern.compile("\\d+");
					Matcher m23=p23.matcher(amo);
					boolean t23=m23.find()&&m23.group().equals(amo);
					System.out.println("t="+t);

					if(t23==false)
					{
						JOptionPane p4=new JOptionPane("Enter proper amount with RS.10,000");
						JDialog d4=p4.createDialog(null,"");
						d4.setAlwaysOnTop(true);
						d4.show();
						int res4 = 0;
						if(res4==JOptionPane.OK_OPTION)
						{
							tamount.setText(null);
						}

					}

					double amount=Double.parseDouble(amo);
					bal=Double.parseDouble(values[4]);
					if(bal>amount&& t==true)
					{
						bal=bal-amount;
						System.out.println("bal="+bal);
						values[4]=Double.toString(bal);
						raf.seek(addr);
						String str=values[0]+","+values[1]+","+values[2]+","+values[3]+","+values[4]+","+values[5]+","+values[6]+","+values[7]+"$";
						File file1=new File(filename2);
						Scanner sc=new Scanner(file1);
						String[] values1;
						
						RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
						while(sc.hasNextLine())
						{
							String mystr=sc.nextLine();
							if(mystr.startsWith("*"))continue;
							System.out.println("here4");
							values1=mystr.split(",");
							
							String ds1=values1[5].replace('$',' ').trim();
							values1[5]=ds1;
							System.out.println(ds1);
							
							if(values1[2].equals(acc))
							{
								
								while(raf2.readLine()!=null)
								{

									raf2.seek(pos);
									pos=(int) raf2.getFilePointer();
									values1=raf2.readLine().split(",");
									System.out.println(values1[2]);
									
									if(values1[2].equals(acc))
									{
										values1[5]=Double.toString(bal);
										String b1=values1[0]+","+values1[1]+","+values1[2]+","+values1[3]+","+values1[4]+","+values1[5];
										System.out.println("am here:"+b1);
										raf2.seek(pos);
										raf2.writeBytes(b1);
										flag=1;		
										raf.seek(addr);
										raf.writeBytes(str);
										break;
									}
									values1=null;
									pos=(int) raf2.getFilePointer();
								}
							}
							
						}
						if(flag==1)
						{
							Date df =new Date();
							String str1=acc+","+amount+","+values[4]+","+df+","+"withdraw$";
							BufferedWriter out2=new BufferedWriter(new FileWriter(filename3,true));
							out2.write(str1);
							out2.newLine();
							out2.close();
							String[] to={values[6]};
							String subject="RS."+amount+" withdrawn from your account";
							String body="Rs."+amount+" has been withdrawn from your account "+acc+" on "+df+" to recharge the number:"+phone+".Total balance is Rs."+bal+".";
							System.out.println(body);
							//sendMail sm=new sendMail();
							Main.sendFromGMail(to,subject,body);
							JOptionPane p5=new JOptionPane("RS."+amount+" Succesfully Recharged To Phone Number:"+phone);
							JDialog d5=p5.createDialog(null,"");
							d5.setAlwaysOnTop(true);
							d5.show();
							int res5 = 0;
							if(res5==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}



						}
						else
						{

							JOptionPane p=new JOptionPane("unsuccesfully");
							JDialog d=p.createDialog(null,"");
							d.setAlwaysOnTop(true);
							d.show();
							int res = 0;
							if(res==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}

						}

					}
					else if(bal<amount)
					{
						JOptionPane p=new JOptionPane("Not Sufficient Balance");
						JDialog d=p.createDialog(null,"");
						d.setAlwaysOnTop(true);
						d.show();
						int res = 0;
						if(res==JOptionPane.OK_OPTION)
						{
							Page_2 pa=new Page_2();
							pa.setVisible(true);
						}

					}
					if(t==false)
					{
						JOptionPane p2=new JOptionPane("Invalid Phone Number");
						JDialog d2=p2.createDialog(null,"");
						d2.setAlwaysOnTop(true);
						d2.show();
						int res2 = 0;
						if(res2==JOptionPane.OK_OPTION)
						{
							tphone.setText(null);
						}
					}

				}	
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
		});
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		btnNewButton.setBounds(137, 197, 151, 25);
		contentPane.add(btnNewButton);

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(78, 71, 274, 151);
		contentPane.add(lblNewLabel);
		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();
		lblNewLabel .setIcon(new ImageIcon(img));
	}
}

