import java.awt.*;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;
import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalExclusionType;
import java.awt.Window.Type;
import java.sql.ResultSet;

import javax.swing.JMenuBar;


public class main_page extends JFrame {

	private JPanel contentPane;
	
	/**
	 * Launch the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws  InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException, ClassNotFoundException {
		
		UIManager.setLookAndFeel( "javax.swing.plaf.metal.MetalLookAndFeel" );
		
		UIManager.setLookAndFeel( "com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel" );
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main_page frame = new main_page();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main_page() {
		setResizable(false);
		//setType(Type.POPUP);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300,100,800,450);
		contentPane = new JPanel();
		contentPane.setForeground(Color.WHITE);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel.setBackground(Color.CYAN);
		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();
		lblNewLabel .setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(229, 111, 323, 150);
		contentPane.add(lblNewLabel);

		JButton btnNewButton = new JButton("ENTER");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//JOptionPane.showMessageDialog(null,"Succesfull");
				Page_1 h=new Page_1();
				h.setVisible(true);


			}
		});
		btnNewButton.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setBounds(326, 318, 121, 37);
		contentPane.add(btnNewButton);
		

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 0, 0));
		panel.setBounds(50, 0, 700, 50);
		contentPane.add(panel);

		JLabel lblDmAssociationBank = new JLabel("DM ASSOCIATION BANK");
		lblDmAssociationBank.setForeground(Color.WHITE);
		lblDmAssociationBank.setVerticalAlignment(SwingConstants.TOP);
		panel.add(lblDmAssociationBank);
		lblDmAssociationBank.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 30));
		lblDmAssociationBank.setBackground(Color.WHITE);

		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 0, 0));
		panel_1.setBounds(0, 50, 50, 320);
		contentPane.add(panel_1);

		Panel panel_2 = new Panel();
		panel_2.setBackground(new Color(255, 0, 0));
		panel_2.setBounds(50, 366, 700, 50);
		contentPane.add(panel_2);

		Panel panel_3 = new Panel();
		panel_3.setBackground(new Color(255, 0, 0));
		panel_3.setBounds(745, 50, 50, 320);
		contentPane.add(panel_3);

		JLabel lblWelcomeToDm = new JLabel("Welcome to DM Association Bank  ATM");
		lblWelcomeToDm.setForeground(Color.RED);
		lblWelcomeToDm.setFont(new Font("Times New Roman", Font.ITALIC, 22));
		lblWelcomeToDm.setBounds(198, 56, 396, 50);
		contentPane.add(lblWelcomeToDm);

		JLabel lblNewLabel_1 = new JLabel("Press enter to continue");
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.ITALIC, 20));
		lblNewLabel_1.setBounds(239, 261, 284, 27);
		contentPane.add(lblNewLabel_1);
	}
}
