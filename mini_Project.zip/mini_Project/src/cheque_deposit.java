import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Panel;
import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class cheque_deposit extends JFrame {

	private JPanel contentPane;
	private JTextField cheque;
	private JTextField taccount;
	Page_1 pg =new Page_1();
	public String acc=pg.acc;
	private JTextField tamount;
	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\display.txt";
	public static  String filename3="C:\\user\\transaction_logs.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					cheque_deposit frame = new cheque_deposit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public cheque_deposit() {
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(400, 200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 444, 40);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 20));
		label.setBackground(Color.RED);
		panel.add(label);

		JLabel lblChequeNo = new JLabel("CHEQUE NO:");
		lblChequeNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblChequeNo.setForeground(Color.RED);
		lblChequeNo.setBackground(Color.WHITE);
		lblChequeNo.setBounds(36, 67, 137, 32);
		contentPane.add(lblChequeNo);

		cheque = new JTextField();
		cheque.setHorizontalAlignment(SwingConstants.CENTER);
		cheque.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		cheque.setBounds(185, 67, 207, 32);
		contentPane.add(cheque);
		cheque.setColumns(10);

		JLabel lblAccountNo = new JLabel("ACCOUNT  NO:");
		lblAccountNo.setForeground(Color.RED);
		lblAccountNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAccountNo.setBounds(36, 123, 137, 16);
		contentPane.add(lblAccountNo);

		taccount = new JTextField();
		taccount.setHorizontalAlignment(SwingConstants.CENTER);
		taccount.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		taccount.setBounds(185, 114, 207, 34);
		contentPane.add(taccount);
		taccount.setColumns(10);

		JButton btnEnter = new JButton("ENTER");
		btnEnter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String account=taccount.getText();
				System.out.println(account);
				String amo=tamount.getText();
				String che=cheque.getText();
				double bal,bal1 ;
				int flag=0,flag1=0,flag2=0,flag3=0,flag4=1;

				try{
					long addr=Math.abs(acc.hashCode()%19937);
					RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
					raf.seek(addr);
					String[] values=raf.readLine().split(",");
					if(!values[0].startsWith("*"))flag=1;
					int pos=values[7].indexOf("$");
					String ds=values[7].substring(0,pos).trim();
					values[7]=ds;
					bal=Double.parseDouble(values[4]);

					
					if(flag==1)
					{
						long addr1=Math.abs(account.hashCode()%19937);
						raf.seek(addr1);
						String mystr=raf.readLine();
						if(mystr.equals(null)||mystr.startsWith("*"))flag3=1;
						String[] values1;
						values1=mystr.split(",");
						if(!values1[0].equals(account))flag4=0;
						int pos1=values1[7].indexOf("$");
						String ds1=values1[7].substring(0,pos1).trim();
						values1[7]=ds1;
						bal1=Double.parseDouble(values1[4]);

						Pattern p16=Pattern.compile("\\d+");
						Matcher m6=p16.matcher(amo);
						boolean t6=m6.find()&&m6.group().equals(amo);
						System.out.println("t="+t6);

						if(t6==false)
						{
							JOptionPane p4=new JOptionPane("Enter proper amount with RS.10,000");
							JDialog d4=p4.createDialog(null,"");
							d4.setAlwaysOnTop(true);
							d4.show();
							int res4 = 0;
							if(res4==JOptionPane.OK_OPTION)
							{
								tamount.setText(null);

							}

						}
						double amount=Double.parseDouble(amo);
						Pattern p1=Pattern.compile("[0-9][0-9][0-9][0-9][0-9]\\d+");
						Matcher m=p1.matcher(che);
						boolean t=m.find()&&m.group().equals(che);
						System.out.println("t="+t);
						if(t==false)
						{
							JOptionPane p11=new JOptionPane("Invalid Cheque Number");
							JDialog d1=p11.createDialog(null,"");
							d1.setAlwaysOnTop(true);
							d1.show();
							int res1 = 0;
							if(res1==JOptionPane.OK_OPTION)
							{
								cheque.setText(null);
							}

						}

						if(bal1>amount&&t==true&&flag4==1&&flag3==0)
						{
							bal=bal+amount;
							bal1=bal1-amount;
							values[4]=Double.toString(bal);
							raf.seek(addr);
							String str=values[0]+","+values[1]+","+values[2]+","+values[3]+","+values[4]+","+values[5]+","+values[6]+","+values[7]+"$";
							File file1=new File(filename2);
							Scanner sc=new Scanner(file1);
							String[] values2;

							RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
							while(sc.hasNextLine())
							{
								String mystr1=sc.nextLine();
								System.out.println(mystr1);
								if(mystr1.startsWith("*"))continue;
								System.out.println("here4");
								values2=mystr1.split(",");
								int posaddr=0;
								String ds2=values2[5].replace('$',' ').trim();
								values2[5]=ds2;
								System.out.println(values2[5]+" "+ds2);

								if(values2[2].equals(acc))
								{

									while(raf2.readLine()!=null)
									{

										raf2.seek(posaddr);
										posaddr=(int) raf2.getFilePointer();
										values2=raf2.readLine().split(",");
										System.out.println(values2[2]);

										if(values2[2].equals(acc))
										{
											values2[5]=Double.toString(bal);
											String b1=values2[0]+","+values2[1]+","+values2[2]+","+values2[3]+","+values2[4]+","+values2[5];
											System.out.println("am here:"+b1);
											raf2.seek(posaddr);
											raf2.writeBytes(b1);	
											raf.seek(addr);
											raf.writeBytes(str);
											flag1=1;	
											break;

										}
										values2=null;
										posaddr=(int) raf2.getFilePointer();

									}
								}
							
							}
							values1[4]=Double.toString(bal1);
							raf.seek(addr1);
							String str1=values1[0]+","+values1[1]+","+values1[2]+","+values1[3]+","+values1[4]+","+values1[5]+","+values1[6]+","+values1[7]+"$";
							File file2=new File(filename2);
							Scanner sc1=new Scanner(file2);
							String[] values3;

							RandomAccessFile raf3 = new RandomAccessFile(filename2, "rw");
							while(sc1.hasNextLine())
							{
								String mystr2=sc1.nextLine();
								if(mystr2.startsWith("*"))continue;
								System.out.println("here4");
								values3=mystr2.split(",");
								int posaddr1=0;
								String ds3=values1[5].replace('$',' ').trim();
								values3[5]=ds3;
								System.out.println(ds3);

								if(values3[2].equals(account))
								{

									while(raf3.readLine()!=null)
									{

										raf3.seek(posaddr1);
										posaddr1=(int) raf3.getFilePointer();
										values3=raf3.readLine().split(",");
										System.out.println(values3[2]);

										if(values3[2].equals(account))
										{
											values3[5]=Double.toString(bal1);
											String b2=values3[0]+","+values3[1]+","+values3[2]+","+values3[3]+","+values3[4]+","+values3[5];
											System.out.println("am here:"+b2);
											raf2.seek(posaddr1);
											raf2.writeBytes(b2);
											flag2=1;		
											raf.seek(addr1);
											raf.writeBytes(str1);
											break;
										}
										values3=null;
										posaddr1=(int) raf3.getFilePointer();

									}
								}
							}
						}
						else if(flag3==1||flag4==0)
						{

							JOptionPane p2=new JOptionPane("Invalid account No");
							JDialog d2=p2.createDialog(null,"");
							d2.setAlwaysOnTop(true);
							d2.show();
							int res2 = 0;
							if(res2==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}

						}
						else if(bal1<amount)
						{

							JOptionPane p2=new JOptionPane("Not Sufficient Amount");
							JDialog d2=p2.createDialog(null,"");
							d2.setAlwaysOnTop(true);
							d2.show();
							int res2 = 0;
							if(res2==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}

						}
						if(flag1==1&&flag2==1)
						{

							Date df =new Date();
							String str11=acc+","+amount+","+values[4]+","+df+","+"Cheque_deposit$";
							String str12=account+","+amount+","+values1[4]+","+df+","+"withdraw$";
							BufferedWriter out2=new BufferedWriter(new FileWriter(filename3,true));
							out2.write(str11);
							out2.newLine();
							out2.write(str12);
							out2.newLine();
							out2.close();
							String[] to={values[6]};
							String subject="RS."+amount+" deposited to your account with cheque number:"+che;
							String body="Rs."+amount+" has been deposited to your account "+acc+" with cheque number "+che+" on "+df+".Total balance is Rs."+bal+".";
							System.out.println(body);
							//sendMail sm=new sendMail();
							Main.sendFromGMail(to,subject,body);


							String[] to1={values1[6]};
							String subject1="RS."+amount+" transfered from your account with cheque number"+che;
							String body1="Rs."+amount+" has been transfered from your account "+account+" to "+acc+" with cheque number:"+che+" on "+df+".Total balance is Rs."+bal1+".";
							System.out.println(body);

							Main.sendFromGMail(to1,subject1,body1);

							JOptionPane p=new JOptionPane("Rs."+amount+" deposited Succesfully From Cheque Number:"+che);
							JDialog d=p.createDialog(null,"");
							d.setAlwaysOnTop(true);
							d.show();
							int res = 0;
							if(res==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}
						}
						else 
						{

							JOptionPane p2=new JOptionPane("Invalid account No");
							JDialog d2=p2.createDialog(null,"");
							d2.setAlwaysOnTop(true);
							d2.show();
							int res2 = 0;
							if(res2==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}

						}
						if(flag3==1)
						{
							JOptionPane p14=new JOptionPane("Invalid Acocount Number");
							JDialog d14=p14.createDialog(null,"");
							d14.setAlwaysOnTop(true);
							d14.show();
							int res14 = 0;
							if(res14==JOptionPane.OK_OPTION)
							{
								tamount.setText(null);
								taccount.setText(null);
							}

						}

					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}


			}
		});
		btnEnter.setBackground(Color.RED);
		btnEnter.setForeground(Color.WHITE);
		btnEnter.setBounds(153, 215, 119, 25);
		contentPane.add(btnEnter);

		JLabel lblAmount = new JLabel("AMOUNT :");
		lblAmount.setForeground(Color.RED);
		lblAmount.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAmount.setBounds(39, 167, 137, 16);
		contentPane.add(lblAmount);

		tamount = new JTextField();
		tamount.setHorizontalAlignment(SwingConstants.CENTER);
		tamount.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		tamount.setBounds(185, 161, 207, 32);
		contentPane.add(tamount);
		tamount.setColumns(10);
	}
}
