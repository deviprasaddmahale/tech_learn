import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JPasswordField;

import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;


public class Page_1<label> extends JFrame {

	private JPanel contentPane;
	public JTextField tf1;
	private JPasswordField tp1;
	public static String acc;

	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\user.txt";
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Page_1 frame = new Page_1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Page_1() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(300,100,800,450);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLACK);
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblPinNumber = new JLabel("PIN NUMBER:");
		lblPinNumber.setForeground(Color.RED);
		lblPinNumber.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblPinNumber.setBounds(124, 213, 178, 22);
		contentPane.add(lblPinNumber);


		JLabel lblAccountNumber = new JLabel(" ACCOUNT NUMBER:");
		lblAccountNumber.setForeground(Color.RED);
		lblAccountNumber.setBackground(Color.WHITE);
		lblAccountNumber.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		lblAccountNumber.setBounds(111, 135, 232, 32);
		contentPane.add(lblAccountNumber);

		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(50, 0, 691, 50);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		label.setForeground(Color.WHITE);
		panel.add(label);
		label.setVerticalAlignment(SwingConstants.TOP);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 30));
		label.setBackground(Color.BLACK);

		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.RED);
		panel_1.setBounds(0, 50, 50, 315);
		contentPane.add(panel_1);

		Panel panel_2 = new Panel();
		panel_2.setBackground(Color.RED);
		panel_2.setBounds(50, 365, 691, 50);
		contentPane.add(panel_2);

		Panel panel_3 = new Panel();
		panel_3.setBackground(Color.RED);
		panel_3.setBounds(744, 50, 50, 315);
		contentPane.add(panel_3);

		tf1 = new JTextField();
		tf1.setHorizontalAlignment(SwingConstants.CENTER);
		tf1.setForeground(Color.BLACK);
		tf1.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		tf1.setBackground(Color.WHITE);


		tf1.setBounds(375, 135, 265, 29);
		contentPane.add(tf1);
		tf1.setColumns(10);

		tp1 = new JPasswordField();
		tp1.setHorizontalAlignment(SwingConstants.CENTER);
		tp1.setEchoChar('*');
		tp1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		tp1.setBounds(377, 206, 263, 29);
		contentPane.add(tp1);
		//acc1=tf1.getText();
		//System.out.println("acc="+acc1.toString());

		JButton btnOk = new JButton("Ok");
		btnOk.setForeground(Color.WHITE);
		btnOk.setBackground(Color.RED);
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				acc=tf1.getText();
				System.out.println("acc="+acc);
				//@SuppressWarnings("deprecation")
				String pin=tp1.getText();
				Pattern p1=Pattern.compile("\\d+");
				Matcher m=p1.matcher(acc);
				boolean t=m.find()&&m.group().equals(acc);
				if(t==false)
				{
					JOptionPane.showMessageDialog(null,"Enter valid account number/ pin number");
				}

				try
				{
					int flag=0,flag1=0;
					long addr=Math.abs(acc.hashCode()%19937);
					RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
					raf.seek(addr);
					String[] values=raf.readLine().split(",");
					if(values[0].startsWith("*"))flag1=1;
					int pos=values[2].indexOf("$");
					String ds=values[2].substring(0,pos).trim();
					values[2]=ds;
					
					if(acc.equals(values[1])&&pin.equals(values[2]))flag=1;
					if(flag==1&&flag1==0)
					{
						//JOptionPane.showMessageDialog(null,"Succesfull");
						//JOptionPane.showMessageDialog(null,"Login succesfull");
						Page_2 h=new Page_2();
						h.setVisible(true);

					}
					else if(flag1==1||flag==0)
					{
						JOptionPane.showMessageDialog(null,"Enter valid account number/ pin number");
						Date df =new Date();
						//String[] to={email};
						String subject="Someone is using your account ";
						String body="Someone is using your account on "+df+".Make sure ,you never  reveal your pin number";
						System.out.println(body);
						//sendMail sm=new sendMail();
						//sendMail.sendFromGMail(to,subject,body);
						
						tf1.setText(null);
						tp1.setText(null);
					}
				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}
			}
		});
		btnOk.setFont(new Font("Times New Roman", Font.BOLD, 20));
		btnOk.setBounds(325, 317, 97, 25);
		contentPane.add(btnOk);

		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
		lblNewLabel.setBounds(236, 87, 306, 213);
		contentPane.add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(img));
	}

}
