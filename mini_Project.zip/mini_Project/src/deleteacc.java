import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;

import javax.swing.JTable;

import net.proteanit.sql.DbUtils;


public class deleteacc extends JFrame {

	private JPanel contentPane;
	private JTextField accn;
	private JTable table;


	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\display.txt";
	public static  String filename3="C:\\user\\user.txt";
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					deleteacc frame = new deleteacc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deleteacc() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 928, 43);
		contentPane.add(panel);

		JLabel lblDeleteAccount = new JLabel("DELETE ACCOUNT");
		lblDeleteAccount.setFont(new Font("Times New Roman", Font.PLAIN, 28));
		panel.add(lblDeleteAccount);
		lblDeleteAccount.setForeground(Color.WHITE);
		lblDeleteAccount.setBackground(Color.RED);

		JLabel lblEnterTheAccount = new JLabel("Enter the account number to be deleted");
		lblEnterTheAccount.setForeground(Color.RED);
		lblEnterTheAccount.setBackground(new Color(240, 240, 240));
		lblEnterTheAccount.setFont(new Font("Times New Roman", Font.PLAIN, 28));
		lblEnterTheAccount.setBounds(100, 97, 457, 31);
		contentPane.add(lblEnterTheAccount);

		accn = new JTextField();
		accn.setHorizontalAlignment(SwingConstants.CENTER);
		accn.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		accn.setBounds(141, 232, 297, 50);
		contentPane.add(accn);
		accn.setColumns(10);



		JButton btnNewButton = new JButton("SUBMIT");
		btnNewButton.addActionListener(new ActionListener() {
			@SuppressWarnings("unused")
			public void actionPerformed(ActionEvent arg0) {
				String accno=accn.getText();


				try{
					int flag=0;
					String[] values;
					String[] values1;
					String[] dvalues={};
					File file1=new File(filename2);
					Scanner sc=new Scanner(file1);
					RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
					int pos=0;
					String bankn=nextpage.bankname;
					while(sc.hasNextLine())
					{
						String mystr=sc.nextLine();
						System.out.println("here41111");
						values=mystr.split(",");
						String ds=values[5].replace('$',' ').trim();
						values[5]=ds;
						System.out.println(ds);
						
						if(values[2].equals(accno))
						{
							System.out.println("ok");
							long addr=Math.abs(accno.hashCode()%19937);
							RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
							raf.seek(addr);
							dvalues=raf.readLine().split(",");
							raf.seek(addr);
							values=null;
							char t= '*';
							raf.write(t);
							RandomAccessFile raf3 = new RandomAccessFile(filename3, "rw");
							raf3.seek(addr);
							raf3.write(t);
							while(raf2.readLine()!=null)
							{

								raf2.seek(pos);
								pos=(int) raf2.getFilePointer();
								String mystr1=raf2.readLine();
								int len=mystr1.length();
								String t1="*";
								for(int i=1;i<len;i++)
									t1=t1+"%";
								values1=mystr1.split(",");
								System.out.println(values1[2]);
								if(values1[2].equals(accno))
								{
									raf2.seek(pos);
									raf2.writeBytes(t1);
									JOptionPane p=new JOptionPane("Account has been deleted");
									JDialog d=p.createDialog(null,"");
									d.setAlwaysOnTop(true);
									d.show();
									int res = 0;
									if(res==JOptionPane.OK_OPTION)
									{
										nextpage np=new nextpage();
										np.setVisible(true);

									}
									flag=1;
									break;
								}
								values1=null;
								pos=(int) raf2.getFilePointer();
							}
						}


					}
					if(flag==1)
					{
						Date df =new Date();
						String[] to={dvalues[6]};  
						String subject="Your account details has beeen updated in our "+bankn+".";
						String body="Mr/Mrs "+dvalues[2] +", your account details has been updated in our "+bankn+" with bearing account number:"+accno
								+" with phone number"+dvalues[5]+" on "+df;
						System.out.println(body);

						Main.sendFromGMail(to,subject,body);
						JOptionPane p=new JOptionPane("Account details has been updated");
						JDialog d=p.createDialog(null,"");
						d.setAlwaysOnTop(true);
						d.show();
						int res = 0;
						if(res==JOptionPane.OK_OPTION)
						{
							nextpage np=new nextpage();
							np.setVisible(true);
						}
					}
					if(flag==0)
					{
						System.out.println("ok here");
						JOptionPane p=new JOptionPane("Enter Proper Account Number");
						JDialog d=p.createDialog(null,"");
						d.setAlwaysOnTop(true);
						d.show();
						int res = 0;
						if(res==JOptionPane.OK_OPTION)
						{
							accn.setText(null);

						}
					}
					

				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}
		});
		btnNewButton.setBackground(Color.RED);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setFont(new Font("Times New Roman", Font.BOLD, 24));
		btnNewButton.setBounds(180, 389, 196, 43);
		contentPane.add(btnNewButton);

		JLabel lblAccountNo = new JLabel("Account no:");
		lblAccountNo.setForeground(Color.RED);
		lblAccountNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAccountNo.setBounds(694, 110, 105, 24);
		contentPane.add(lblAccountNo);
		String bankn=nextpage.bankname;
		try{
			String[] values;
			Object[][] row=new Object[20][1];
			File file1=new File(filename2);
			Scanner sc=new Scanner(file1);
			int j=0;
			while(sc.hasNextLine())
			{
				String mystr=sc.nextLine();
				System.out.println(mystr);
				if(mystr.startsWith("*"))continue;
				System.out.println("here4");
				values=mystr.split(",");
				String ds=values[5].replace('$',' ').trim();
				values[5]=ds;
				System.out.println(ds);

				if(values[0].equals(bankn))
				{
					System.out.println("here5");
					row[j][0]=values[2];
					System.out.println(row[j][0]);
					values=null;
					j++;
				}



			}
			Object[] colname={"Account no"};

			table = new JTable(row,colname);
			JScrollPane scrollp = new JScrollPane(table);

			System.out.println("ok");
			table.setBounds(85,100,100,100);
			table.setBackground(Color.WHITE);
			table.setForeground(Color.BLACK);
			table.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			contentPane.add(table);
			//table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
			scrollp.setViewportView(table);
			scrollp.setBounds(694, 150, 163, 328);
			scrollp.setBackground(Color.WHITE);
			scrollp.setForeground(Color.BLACK);
			scrollp.setFont(new Font("Times New Roman", Font.PLAIN, 18));
			scrollp.getHorizontalScrollBar();
			scrollp.getVerticalScrollBar();
			contentPane.add(scrollp);




		}
		catch(Exception e1)
		{
			System.out.println(e1);
		}



	}
}
