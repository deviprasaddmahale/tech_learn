import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;








import java.awt.Color;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Font;
import java.awt.Window;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.sql.Connection;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
public class withdraw extends JFrame {

	private JPanel contentPane;
	public JTextField tamount;
	Page_1 pg =new Page_1();
	public String acc=pg.acc;


	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\display.txt";
	public static  String filename3="C:\\user\\transaction_logs.txt";
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					withdraw frame = new withdraw();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}



	/**
	 * Create the frame.
	 */
	public withdraw() {
		System.out.println("acc="+acc);
		setAlwaysOnTop(true);
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(400,200, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JComboBox acc_type = new JComboBox();
		acc_type.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		acc_type.setModel(new DefaultComboBoxModel(new String[] {"CURRENT", "SAVINGS"}));
		acc_type.setForeground(Color.BLACK);
		acc_type.setBackground(Color.WHITE);
		acc_type.setBounds(192, 149, 198, 22);
		contentPane.add(acc_type);
		tamount = new JTextField();
		tamount.setHorizontalAlignment(SwingConstants.CENTER);
		tamount.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		tamount.setBounds(190, 94, 200, 22);
		contentPane.add(tamount);
		tamount.setColumns(10);



		JButton btnEnter = new JButton("ENTER");
		btnEnter.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				//	

				//	System.out.println("ok");

				String amo=tamount.getText();

				double bal ;
				String email;
				String ac_type=acc_type.getSelectedItem().toString();
				String ac_type1;
				
				


				try{
					int flag=0;
					long addr=Math.abs(acc.hashCode()%19937);
					RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
					raf.seek(addr);
					String[] values=raf.readLine().split(",");
					int pos=values[7].indexOf("$");
					String ds=values[7].substring(0,pos);
					values[7]=ds;
					
					boolean b=ac_type.equalsIgnoreCase(values[3]);
					Pattern p1=Pattern.compile("\\d+");
					Matcher m=p1.matcher(amo);
					boolean t=m.find()&&m.group().equals(amo);
					System.out.println("t="+t);

					if(t==false)
					{
						JOptionPane p4=new JOptionPane("Enter proper amount within RS.10,000");
						JDialog d4=p4.createDialog(null,"");
						d4.setAlwaysOnTop(true);
						d4.show();
						int res4 = 0;
						if(res4==JOptionPane.OK_OPTION)
						{
							tamount.setText(null);
							acc_type.setSelectedIndex(0);
						}

					}

					double amount=Double.parseDouble(amo);
					bal=Double.parseDouble(values[4]);
					if(bal>amount && b==true && t==true)
					{
						bal=bal-amount;
						values[4]=Double.toString(bal);
						raf.seek(addr);
						String str=values[0]+","+values[1]+","+values[2]+","+values[3]+","+values[4]+","+values[5]+","+values[6]+","+values[7]+"$";
						File file1=new File(filename2);
						Scanner sc=new Scanner(file1);
						String[] values1;
						
						RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
						while(sc.hasNextLine())
						{
							String mystr=sc.nextLine();
							if(mystr.startsWith("*"))continue;
							System.out.println("here4");
							values1=mystr.split(",");
							
							String ds1=values1[5].replace('$',' ').trim();
							values1[5]=ds1;
							System.out.println(ds1);
							
							if(values1[2].equals(acc))
							{
								
								while(raf2.readLine()!=null)
								{

									raf2.seek(pos);
									pos=(int) raf2.getFilePointer();
									values1=raf2.readLine().split(",");
									System.out.println(values1[2]);
									
									if(values1[2].equals(acc))
									{
										values1[5]=Double.toString(bal);
										String b1=values1[0]+","+values1[1]+","+values1[2]+","+values1[3]+","+values1[4]+","+values1[5];
										System.out.println("am here:"+b1);
										raf2.seek(pos);
										raf2.writeBytes(b1);
										flag=1;		
										raf.seek(addr);
										raf.writeBytes(str);
										break;
									}
									values1=null;
									pos=(int) raf2.getFilePointer();
								}
							}
							
						}

						
						if(flag==1)
						{
							Date df =new Date();
							String str1=acc+","+amount+","+values[4]+","+df+","+"withdraw$";
							BufferedWriter out2=new BufferedWriter(new FileWriter(filename3,true));
							out2.write(str1);
							out2.newLine();
							out2.close();
							String[] to={values[6]};
							String subject="RS."+amount+" withdrawn from your account";
							String body="Rs."+amount+" has been withdrawn from your account "+acc+" on "+df+".Total balance is Rs."+bal+".";
							System.out.println(body);
							
							Main.sendFromGMail(to,subject,body);
							
							JOptionPane p=new JOptionPane("Rs."+amount+" Withdrawn Succesfully");
							JDialog d=p.createDialog(null,"");
							d.setAlwaysOnTop(true);
							d.show();
							int res = 0;
							if(res==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}
							

						}
						else
						{

							JOptionPane p11=new JOptionPane("unsuccesfully");
							JDialog d1=p11.createDialog(null,"");
							d1.setAlwaysOnTop(true);
							d1.show();
							int res1 = 0;
							if(res1==JOptionPane.OK_OPTION)
							{
								Page_2 pa=new Page_2();
								pa.setVisible(true);
							}

						}
					}
					else if(bal<amount)
					{
						JOptionPane p3=new JOptionPane("No Sufficient Amount");
						JDialog d3=p3.createDialog(null,"");
						d3.setAlwaysOnTop(true);
						d3.show();
						int res3 = 0;
						if(res3==JOptionPane.OK_OPTION)
						{
							Page_2 pa=new Page_2();
							pa.setVisible(true);
						}

					}
					if(b==false)
					{
						JOptionPane p2=new JOptionPane("Invalid Account Type");
						JDialog d2=p2.createDialog(null,"");
						d2.setAlwaysOnTop(true);
						d2.show();
						int res2 = 0;
						if(res2==JOptionPane.OK_OPTION)
						{
							acc_type.setSelectedIndex(0);
						}
					}


				}	
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}


			}
		});



		JLabel lblAccountType = new JLabel("ACCOUNT TYPE:");
		lblAccountType.setForeground(Color.RED);
		lblAccountType.setHorizontalAlignment(SwingConstants.CENTER);
		lblAccountType.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAccountType.setBounds(12, 150, 153, 16);
		contentPane.add(lblAccountType);
		btnEnter.setBackground(Color.RED);
		btnEnter.setForeground(Color.WHITE);
		btnEnter.setFont(new Font("Times New Roman", Font.PLAIN, 22));
		btnEnter.setBounds(150, 215, 133, 25);
		contentPane.add(btnEnter);



		Panel panel = new Panel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 444, 40);
		contentPane.add(panel);

		JLabel label = new JLabel("DM ASSOCIATION BANK");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setForeground(Color.WHITE);
		label.setFont(new Font("High Tower Text", Font.BOLD | Font.ITALIC, 20));
		label.setBackground(Color.RED);
		panel.add(label);

		JLabel lblAmount = new JLabel("AMOUNT:");
		lblAmount.setForeground(Color.RED);
		lblAmount.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		lblAmount.setBounds(12, 95, 97, 16);
		contentPane.add(lblAmount);

		JLabel lblNewLabel = new JLabel("");
		Image img=new ImageIcon(this.getClass().getResource("/dm.png")).getImage();
		lblNewLabel .setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(48, 70, 311, 153);
		contentPane.add(lblNewLabel);
	}
}
