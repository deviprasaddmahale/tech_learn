import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Color;

import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;


public class createacc extends JFrame {

	private JPanel contentPane;
	private JTextField accno;
	private JTextField ifsc;
	private JPasswordField pin;
	private JLabel lblPinNumber;
	private JLabel lblNewLabel_1;
	private JLabel lblIfscCode;
	private JTextField bankid;
	private JLabel lblBankId;
	private JTextField userid;
	private JLabel lblUserId;
	private JLabel lblaccountHolderDetails;
	private JLabel lblAccountType;
	private JComboBox acctype;
	private JTextField holdername;
	private JTextField email;
	private JTextField phone;
	private JTextField balance;

	/**
	 * Launch the application.
	 */
	public static  String filename1="C:\\user\\account.txt";
	public static  String filename2="C:\\user\\user.txt";
	public static  String filename3="C:\\user\\display.txt";
	public static void main(String[] args) throws IOException {
		File file1=new File(filename1);
		file1.createNewFile();
		File file2 =new File(filename2);
		file2.createNewFile();
		File file3 =new File(filename3);
		file3.createNewFile();


		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					createacc frame = new createacc();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public createacc() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 934, 553);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.RED);
		panel.setBounds(0, 0, 933, 52);
		contentPane.add(panel);

		JLabel lblNewLabel = new JLabel("CREATE ACCOUNT");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
		panel.add(lblNewLabel);

		accno = new JTextField();
		accno.setEditable(false);
		accno.setHorizontalAlignment(SwingConstants.CENTER);
		accno.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		accno.setBounds(22, 111, 261, 34);
		contentPane.add(accno);
		accno.setColumns(10);

		JLabel lblAccountNumber = new JLabel("Account number");
		lblAccountNumber.setForeground(Color.RED);
		lblAccountNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblAccountNumber.setBounds(22, 85, 153, 26);
		contentPane.add(lblAccountNumber);

		ifsc = new JTextField();
		ifsc.setEditable(false);
		ifsc.setHorizontalAlignment(SwingConstants.CENTER);
		ifsc.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		ifsc.setBounds(664, 112, 252, 34);
		contentPane.add(ifsc);
		ifsc.setColumns(10);

		pin = new JPasswordField();
		pin.setEditable(false);
		pin.setEchoChar('*');
		pin.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		pin.setHorizontalAlignment(SwingConstants.CENTER);
		pin.setBounds(354, 111, 261, 34);
		contentPane.add(pin);

		lblPinNumber = new JLabel("Pin number");
		lblPinNumber.setForeground(Color.RED);
		lblPinNumber.setBackground(Color.WHITE);
		lblPinNumber.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblPinNumber.setBounds(354, 87, 101, 22);
		contentPane.add(lblPinNumber);

		lblNewLabel_1 = new JLabel("------------------------------------------------------------------------------------BANK DETAILS(ENTERED AUTOMATICALLY)-----------------------------------------------------------------------------------------------------");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(Color.RED);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(0, 69, 933, 16);
		contentPane.add(lblNewLabel_1);

		lblIfscCode = new JLabel("Ifsc code");
		lblIfscCode.setForeground(Color.RED);
		lblIfscCode.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblIfscCode.setBounds(666, 87, 80, 22);
		contentPane.add(lblIfscCode);

		bankid = new JTextField();
		bankid.setEditable(false);
		bankid.setHorizontalAlignment(SwingConstants.CENTER);
		bankid.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		bankid.setBounds(169, 188, 261, 34);
		contentPane.add(bankid);
		bankid.setColumns(10);

		lblBankId = new JLabel("Bank ID");
		lblBankId.setForeground(Color.RED);
		lblBankId.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblBankId.setBounds(169, 160, 73, 26);
		contentPane.add(lblBankId);

		userid = new JTextField();
		userid.setEditable(false);
		userid.setHorizontalAlignment(SwingConstants.CENTER);
		userid.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		userid.setBounds(555, 188, 261, 34);
		contentPane.add(userid);
		userid.setColumns(10);

		lblUserId = new JLabel("User ID");
		lblUserId.setForeground(Color.RED);
		lblUserId.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblUserId.setBounds(555, 162, 65, 22);
		contentPane.add(lblUserId);

		lblaccountHolderDetails = new JLabel("---------------------------------------------------------------------------------------------ACCOUNT HOLDER DETAILS--------------------------------------------------------------------------------------------");
		lblaccountHolderDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblaccountHolderDetails.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblaccountHolderDetails.setForeground(Color.RED);
		lblaccountHolderDetails.setBounds(0, 235, 928, 22);
		contentPane.add(lblaccountHolderDetails);

		lblAccountType = new JLabel("Account type");
		lblAccountType.setForeground(Color.RED);
		lblAccountType.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblAccountType.setBounds(561, 363, 108, 22);
		contentPane.add(lblAccountType);

		acctype = new JComboBox();
		acctype.setBackground(Color.WHITE);
		acctype.setModel(new DefaultComboBoxModel(new String[] {"CURRENT", "SAVINGS"}));
		acctype.setForeground(Color.BLACK);
		acctype.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		acctype.setBounds(502, 384, 250, 34);
		contentPane.add(acctype);

		holdername = new JTextField();
		holdername.setHorizontalAlignment(SwingConstants.CENTER);
		holdername.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		holdername.setColumns(10);
		holdername.setBounds(22, 307, 261, 34);
		contentPane.add(holdername);

		email = new JTextField();
		email.setHorizontalAlignment(SwingConstants.CENTER);
		email.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		email.setColumns(10);
		email.setBounds(354, 307, 261, 34);
		contentPane.add(email);

		phone = new JTextField();
		phone.setHorizontalAlignment(SwingConstants.CENTER);
		phone.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		phone.setColumns(10);
		phone.setBounds(664, 307, 252, 34);
		contentPane.add(phone);

		balance = new JTextField();
		balance.setHorizontalAlignment(SwingConstants.CENTER);
		balance.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		balance.setColumns(10);
		balance.setBounds(169, 384, 261, 34);
		contentPane.add(balance);

		JLabel lblHolderName = new JLabel("Holder Name");
		lblHolderName.setForeground(Color.RED);
		lblHolderName.setBackground(Color.WHITE);
		lblHolderName.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblHolderName.setBounds(22, 280, 108, 23);
		contentPane.add(lblHolderName);

		JLabel lblEmailId = new JLabel("Email ID");
		lblEmailId.setForeground(Color.RED);
		lblEmailId.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblEmailId.setBounds(354, 283, 101, 16);
		contentPane.add(lblEmailId);

		JLabel lblPhoneNo = new JLabel("Phone No..");
		lblPhoneNo.setForeground(Color.RED);
		lblPhoneNo.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblPhoneNo.setBounds(681, 281, 103, 20);
		contentPane.add(lblPhoneNo);

		JLabel lblBalance = new JLabel("Balance");
		lblBalance.setForeground(Color.RED);
		lblBalance.setFont(new Font("Times New Roman", Font.PLAIN, 18));
		lblBalance.setBounds(169, 366, 73, 16);
		contentPane.add(lblBalance);


		JButton btnSubmit = new JButton("SUBMIT");
		btnSubmit.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent arg0) {
				String bankname=nextpage.bankname;
				System.out.println("bank1="+bankname);
				String bankid1=null;
				String ifsc1=null;

				try{
					String filename="C:\\user\\bank.txt";
					File file1=new File(filename);
					Scanner sc=new Scanner(file1);
					int flag=1;
					while(sc.hasNextLine())
					{
						String mystr=sc.nextLine();

						System.out.println("record:"+mystr);
						String[] values=mystr.split(",");
						System.out.println("bankname:"+values[0]);
						boolean yes=values[0].equalsIgnoreCase(bankname);
						if(yes);
						{
							System.out.println("is there");
							bankid1=values[1];
							System.out.println("bankid1="+bankid1);

							ifsc1=values[2].replace('$',' ').trim();
							System.out.println("ifsc1="+ifsc1);
							if(yes)flag=0;
						}	
						values[0]=null;
						values[1]=null;
						values[2]=null;

						if(flag==0)break;
					}

				}
				catch(Exception e1)
				{
					System.out.println(e1);
				}


				Random rand=new Random();
				int accono=rand.nextInt((99999-10000)+100000);
				String accountno=Integer.toString(accono);
				accno.setText(ifsc1+accountno);
				int pinnumber=rand.nextInt((9999-1000)+1000);
				String pinno=Integer.toString(pinnumber);
				pin.setText(pinno);
				System.out.println(pinnumber);
				ifsc.setText(ifsc1);
				bankid.setText(bankid1);

				int user=rand.nextInt(10000);
				String useri1=Integer.toString(user);

				userid.setText(useri1);

				String bank=bankid.getText();
				String useri=userid.getText();
				String name=holdername.getText();
				Pattern po=Pattern.compile("[a-zA-Z]+([ '.][a-zA-Z]+)*" );
				Matcher mo=po.matcher(name);
				boolean to1=mo.find()&&mo.group().equals(name);
				if(to1==false)
				{
					JOptionPane p141=new JOptionPane("Enter proper name");
					JDialog d141=p141.createDialog(null,"");
					d141.setAlwaysOnTop(true);
					d141.show();
					int res141 = 0;
					if(res141==JOptionPane.OK_OPTION)
					{
						holdername.setText(null);

					}

				}
				String emailid=email.getText();
				Pattern p1=Pattern.compile("^[a-zA-Z0-9_+&*-]+(?:\\."+ 
						"[a-zA-Z0-9_+&*-]+)*@" + 
						"(?:[a-zA-Z0-9-]+\\.)+[a-z" + 
						"A-Z]{2,7}$" );
				Matcher m=p1.matcher(emailid);
				boolean t=m.find()&&m.group().equals(emailid);
				if(t==false)
				{
					JOptionPane p41=new JOptionPane("Enter proper email id");
					JDialog d41=p41.createDialog(null,"");
					d41.setAlwaysOnTop(true);
					d41.show();
					int res41 = 0;
					if(res41==JOptionPane.OK_OPTION)
					{
						email.setText(null);

					}

				}

				String phoneno=phone.getText();
				Pattern p2=Pattern.compile("(0/91)?[7-9][0-9]{9}");
				Matcher m1=p2.matcher(phoneno);
				boolean t1=m1.find()&&m1.group().equals(phoneno);
				if(t1==false)
				{
					JOptionPane p4=new JOptionPane("Enter proper phone number");
					JDialog d4=p4.createDialog(null,"");
					d4.setAlwaysOnTop(true);
					d4.show();
					int res4 = 0;
					if(res4==JOptionPane.OK_OPTION)
					{
						phone.setText(null);

					}

				}
				String ifsccode=ifsc.getText();
				String acc=accno.getText();

				String bal1=balance.getText();
				Pattern p11=Pattern.compile("\\d+");
				Matcher m11=p11.matcher(bal1);
				boolean t11=m11.find()&&m11.group().equals(bal1);
				double bal=Double.parseDouble(bal1);
				if(t11==false)
				{
					JOptionPane p411=new JOptionPane("Enter proper balance amount");
					JDialog d411=p411.createDialog(null,"");
					d411.setAlwaysOnTop(true);
					d411.show();
					int res411 = 0;
					if(res411==JOptionPane.OK_OPTION)
					{
						balance.setText(null);

					}

				}


				System.out.println(bankname);
				String accountt=acctype.getSelectedItem().toString().toLowerCase();



				try
				{
					if(t==true&&t1==true&&t11==true&&to1==true)
					{
						String b=acc+","+pinno+","+name+","+accountt+","+bal+","+phoneno+","+emailid+","+bank+"$";
						String c=user+","+acc+","+pinno+"$";
						String st=bankname+","+ifsccode+","+acc+","+name+","+accountt+","+bal+"$";
						long addr=Math.abs(acc.hashCode()%19937);
						RandomAccessFile raf = new RandomAccessFile(filename1, "rw");
						raf.seek(addr);
						System.out.println("address:"+addr);
						raf.writeBytes(b);
						RandomAccessFile raf2 = new RandomAccessFile(filename2, "rw");
						raf2.seek(addr);
						raf2.writeBytes(c);
						RandomAccessFile raf3= new RandomAccessFile(filename3, "rw");
						raf3.seek(0);
						
						while(true)
						{
							
							long pos=raf3.getFilePointer();
							String mystr1=raf3.readLine();
							if(mystr1==null||mystr1.startsWith("*"))
							{
								raf3.seek(pos);
								raf3.writeBytes(st+'\n');
							
								break;

							}
						}
						if(t==true&&t1==true&&t11==true)
						{
							Date df =new Date();
							String[] to={emailid};  
							String subject="An account has beeen created in our bank "+bankname+".";
							String body="Mr/Mrs "+ name +" your account has been created in our bank "+bankname+" with bearing account number:"+acc+",pin number:"+pinno+",account type:"+accountt+" with initial balance:"+bal+ " on "+df;

							System.out.println(body);

							Main.sendFromGMail(to,subject,body);
							JOptionPane p=new JOptionPane("Account has been created ");
							JDialog d=p.createDialog(null,"");
							d.setAlwaysOnTop(true);
							d.show();
							int res = 0;
							if(res==JOptionPane.OK_OPTION)
							{
								nextpage np=new nextpage();
								np.setVisible(true);

							}

						}
						else
						{
							JOptionPane pw=new JOptionPane("Unsussecfull! Account has not been created ");
							JDialog dw=pw.createDialog(null,"");
							dw.setAlwaysOnTop(true);
							dw.show();
							int resw = 0;
							if(resw==JOptionPane.OK_OPTION)
							{
								nextpage np=new nextpage();
								np.setVisible(true);

							}
						}
					}
					else
					{
						JOptionPane pw=new JOptionPane("Enter proper details");
						JDialog dw=pw.createDialog(null,"");
						dw.setAlwaysOnTop(true);
						dw.show();
						int resw = 0;
						if(resw==JOptionPane.OK_OPTION)
						{
							email.setText(null);
							balance.setText(null);
							phone.setText(null);
							accno.setText(null);
							ifsc.setText(null);
							userid.setText(null);
							bankid.setText(null);
							holdername.setText(null);
							pin.setText(null);


						}
					}
				}
				catch(Exception e)
				{
					System.out.println(e);
				}
			}

		});
		btnSubmit.setBackground(Color.RED);
		btnSubmit.setForeground(Color.WHITE);
		btnSubmit.setFont(new Font("Times New Roman", Font.PLAIN, 24));
		btnSubmit.setBounds(367, 444, 215, 50);
		contentPane.add(btnSubmit);

	}
}
